# Upgraded Shulkers

Iron, Gold, Diamond, Netherite shulkers and more!

Get it at https://www.curseforge.com/minecraft/mc-mods/upgraded-shulkers
