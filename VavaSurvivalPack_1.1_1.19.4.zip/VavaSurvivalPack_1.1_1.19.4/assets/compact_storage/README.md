![CompactStorage Logo](https://i.imgur.com/QY6VKau.jpg)
# Compact Storage for Minecraft Fabric 1.19
Welcome to the new version of Compact Storage, here for Fabric 1.19! This update is primarily focused
on brining the mod up to the latest version of Minecraft with no features added. This also focuses on creating feature parity
between the Forge and Fabric versions of the mod. Forge 1.19 is in the works and will
hopefully be released shortly after 1.19 Fabric. 

You can find the mod on [Curse Forge](https://www.curseforge.com/minecraft/mc-mods/compactstorage) and [Modrinth]()